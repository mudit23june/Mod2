package com.capgemini.application.SpringMVCdb.exception;

@SuppressWarnings("serial")
public class DuplicatePhoneNo extends RuntimeException
{

}
