package com.capgemini.application.SpringMVCdb.exception;

@SuppressWarnings("serial")
public class PhoneNoDoesNotExist extends RuntimeException
{

}
