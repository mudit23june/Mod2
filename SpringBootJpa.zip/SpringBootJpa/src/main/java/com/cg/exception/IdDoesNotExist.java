package com.cg.exception;

@SuppressWarnings("serial")
public class IdDoesNotExist extends RuntimeException
{
	
}
