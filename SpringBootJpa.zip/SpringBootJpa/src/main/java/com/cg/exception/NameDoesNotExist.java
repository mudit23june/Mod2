package com.cg.exception;

@SuppressWarnings("serial")
public class NameDoesNotExist extends RuntimeException
{
	
}
