package com.cg.exception;

@SuppressWarnings("serial")
public class DuplicatePhoneNo extends RuntimeException
{

}
